#pragma once

HBITMAP CreateDesktopBitmap(HWND hWnd);
HBITMAP CreateDesktopMaskBitmap(HWND hWnd);
HWND SmallestWindowFromCursor(RECT& rcWindow);
